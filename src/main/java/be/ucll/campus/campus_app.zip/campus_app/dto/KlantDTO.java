package be.ucll.campus.campus_app.dto;

import be.ucll.campus.campus_app.model.User;

public class KlantDTO {
    private Long id;
    private String naam;

    public KlantDTO(Long id, String naam) {
        this.id = id;
        this.naam = naam;
    }

    public static KlantDTO fromUser(User gebruiker) {
        return new KlantDTO(gebruiker.getId(), gebruiker.getNaam());
    }

    // Getters en setters
    public Long getId() { return id; }
    public String getNaam() { return naam; }
}
