package be.ucll.campus.campus_app.service;

import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import be.ucll.campus.campus_app.exception.*;
import be.ucll.campus.campus_app.model.*;
import be.ucll.campus.campus_app.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.Optional;
import java.util.Set;


@Service
public class ReservatieCliService {

    private final WebClient webClient;
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");

    public ReservatieCliService(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.baseUrl("http://localhost:8080").build();
    }

    public void reservatieMenu(Scanner scanner) {
        boolean running = true;
        while (running) {
            System.out.println("\n--- Reservatie Beheer ---");
            System.out.println("1. Bekijk alle reservaties");
            System.out.println("2. Voeg een reservatie toe");
            System.out.println("3. Verwijder een reservatie");
            System.out.println("4. Terug naar hoofdmenu");
            System.out.print("Kies een optie: ");

            try {
                int keuze = Integer.parseInt(scanner.nextLine().trim());
                switch (keuze) {
                    case 1 -> viewAllReservations();
                    case 2 -> addReservation(scanner);
                    case 3 -> deleteReservation(scanner);
                    case 4 -> running = false;
                    default -> System.out.println("Ongeldige keuze, probeer opnieuw.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Ongeldige invoer, voer een nummer in.");
            }
        }
    }

    private void viewAllReservations() {
        try {
            String response = webClient.get()
                    .uri("/reservaties")
                    .accept(MediaType.APPLICATION_JSON)
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();
            System.out.println("Reservaties: " + response);
        } catch (Exception e) {
            System.out.println("Fout bij ophalen reservaties: " + e.getMessage());
        }
    }

    public void addReservation(Scanner scanner) {
        try {
            System.out.print("Voer user ID in: ");
            Long userId = Long.parseLong(scanner.nextLine().trim());

            System.out.print("Voer starttijd (yyyy-MM-dd'T'HH:mm) in: ");
            String startTijdInput = scanner.nextLine().trim();
            LocalDateTime startTijd = LocalDateTime.parse(startTijdInput, FORMATTER);

            System.out.print("Voer eindtijd (yyyy-MM-dd'T'HH:mm) in: ");
            String eindTijdInput = scanner.nextLine().trim();
            LocalDateTime eindTijd = LocalDateTime.parse(eindTijdInput, FORMATTER);

            if (startTijd.isAfter(eindTijd)) {
                throw new InvalidReservationException("Starttijd moet vóór de eindtijd liggen.");
            }

            if (eindTijd.isBefore(LocalDateTime.now())) {
                throw new InvalidReservationException("Reservatie kan niet in het verleden liggen.");
            }

            System.out.print("Voer lokaal ID's in (gescheiden door komma's): ");
            String lokaalIdsInput = scanner.nextLine().trim();
            String lokaalIdsQuery = String.join(",", lokaalIdsInput.split("\\s*,\\s*"));

            String requestBody = String.format(
                    "{\"startTijd\":\"%s\", \"eindTijd\":\"%s\", \"commentaar\":\"%s\"}",
                    startTijd, eindTijd, "Geen commentaar"
            );

            String response = webClient.post()
                    .uri(uriBuilder -> uriBuilder
                            .path("/reservaties/user/" + userId)
                            .queryParam("lokaalIds", lokaalIdsQuery)
                            .build())
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(Mono.just(requestBody), String.class)
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            System.out.println("Reservatie succesvol toegevoegd: " + response);
        } catch (DateTimeParseException e) {
            System.out.println("Fout: Ongeldig datumformaat. Gebruik: yyyy-MM-dd'T'HH:mm");
        } catch (NumberFormatException e) {
            System.out.println("Fout: Ongeldige invoer voor ID's.");
        } catch (InvalidReservationException e) {
            System.out.println("Fout: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Fout bij toevoegen reservatie: " + e.getMessage());
        }
    }

    private void deleteReservation(Scanner scanner) {
        try {
            System.out.print("Voer ID van te verwijderen reservatie in: ");
            long id = Long.parseLong(scanner.nextLine().trim());

            webClient.delete()
                    .uri("/reservaties/" + id)
                    .retrieve()
                    .onStatus(status -> status.is4xxClientError(), response -> {
                        System.out.println("Reservatie niet gevonden.");
                        return response.createException();
                    })
                    .bodyToMono(Void.class)
                    .block();
            System.out.println("Reservatie verwijderd.");
        } catch (Exception e) {
            System.out.println("Fout bij verwijderen reservatie: " + e.getMessage());
        }
    }
}
