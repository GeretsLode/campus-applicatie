package be.ucll.campus.campus_app.controller;

import be.ucll.campus.campus_app.model.Reservatie;
import be.ucll.campus.campus_app.service.ReservatieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import be.ucll.campus.campus_app.dto.ReservatieDTO;
import java.util.stream.Collectors;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@RestController
@RequestMapping("/reservaties")
public class ReservatieController {

    private final ReservatieService reservatieService;

    @Autowired
    public ReservatieController(ReservatieService reservatieService) {
        this.reservatieService = reservatieService;
    }



    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ReservatieDTO>> getAllReservaties() {
        List<ReservatieDTO> reservatieDTOS = reservatieService.getAllReservaties() // Zorg dat dit List<Reservatie> is
                .stream()
                .map(ReservatieDTO::fromReservatie) // Expliciete lambda i.p.v. method reference
                .collect(Collectors.toList());

        return ResponseEntity.ok(reservatieDTOS);
    }


    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Reservatie> getReservatieById(@PathVariable Long id) {
        Optional<Reservatie> reservatie = reservatieService.getReservatieById(id);
        return reservatie.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping(value = "/user/{userId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Reservatie>> getReservatiesByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(reservatieService.getReservatiesByUserId(userId));
    }

    @PostMapping(value = "/user/{userId}", produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Reservatie> addReservatie(@PathVariable Long userId,
                                                    @RequestBody Reservatie reservatie,
                                                    @RequestParam Set<Long> lokaalIds) {
        Reservatie nieuweReservatie = reservatieService.addReservatie(
                userId,
                reservatie.getStartTijd().toString(),
                reservatie.getEindTijd().toString(),
                lokaalIds);
        return ResponseEntity.ok(nieuweReservatie);
    }


    @DeleteMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> deleteReservatie(@PathVariable Long id) {
        reservatieService.deleteReservatie(id);
        return ResponseEntity.noContent().build();
    }
}
