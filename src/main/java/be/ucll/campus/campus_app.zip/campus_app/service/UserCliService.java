package be.ucll.campus.campus_app.service;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import be.ucll.campus.campus_app.model.User;
import reactor.core.publisher.Mono;


import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

@Service
public class UserCliService {
    private final WebClient webClient;

    public UserCliService(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.baseUrl("http://localhost:8080").build();
    }

    public void userMenu(Scanner scanner) {
        while (true) {
            System.out.println("\n1. Bekijk alle gebruikers");
            System.out.println("2. Gebruiker toevoegen");
            System.out.println("3. Gebruiker verwijderen");
            System.out.println("4. Terug naar hoofdmenu");
            System.out.print("Kies een optie: ");
            int keuze = Integer.parseInt(scanner.nextLine());

            switch (keuze) {
                case 1 -> getUsers();
                case 2 -> addUser(scanner);
                case 3 -> deleteUser(scanner);
                case 4 -> { return; }
                default -> System.out.println("Ongeldige keuze.");
            }
        }
    }

    private void getUsers() {
        try {
            List<User> users = Arrays.asList(webClient.get()
                    .uri("/users")
                    .retrieve()
                    .bodyToMono(User[].class)
                    .block());

            users.forEach(user -> System.out.println(user.getId() + ". " + user.getVoornaam() + " " + user.getNaam() + " (" + user.getEmail() + ")"));
        } catch (WebClientResponseException e) {
            System.out.println("Fout bij het ophalen van gebruikers: " + e.getMessage());
        }
    }

    private void addUser(Scanner scanner) {
        System.out.print("Voornaam: ");
        String voornaam = scanner.nextLine().trim();
        System.out.print("Naam: ");
        String naam = scanner.nextLine().trim();
        System.out.print("Email: ");
        String email = scanner.nextLine().trim();
        System.out.print("Geboortedatum (YYYY-MM-DD): ");
        LocalDate geboortedatum = null;
        while (geboortedatum == null) {
            try {
                String input = scanner.nextLine();
                geboortedatum = LocalDate.parse(input);
            } catch (DateTimeParseException e) {
                System.out.print("Ongeldige datum, gebruik formaat YYYY-MM-DD: ");
            }
        }

        User user = new User(naam, voornaam, email, geboortedatum);

        try {
            User createdUser = webClient.post()
                    .uri("/users")
                    .bodyValue(user)
                    .retrieve()
                    .bodyToMono(User.class)
                    .block();
            System.out.println("Gebruiker toegevoegd: " + createdUser.getVoornaam() + " " + createdUser.getNaam());
        } catch (WebClientResponseException e) {
            System.out.println("Fout bij toevoegen van gebruiker: " + e.getMessage());
        }
    }

    private void deleteUser(Scanner scanner) {
        System.out.print("Voer het ID in van de gebruiker die je wilt verwijderen: ");
        long id = Long.parseLong(scanner.nextLine().trim());

        try {
            webClient.delete()
                    .uri("/users/" + id)
                    .retrieve()
                    .onStatus(status -> status.is4xxClientError(), response ->
                            response.createException().flatMap(Mono::error))
                    .bodyToMono(Void.class)
                    .block();
            System.out.println("Gebruiker verwijderd.");
        } catch (WebClientResponseException e) {
            System.out.println("Fout bij verwijderen van gebruiker: " + e.getMessage());
        }
    }

}
