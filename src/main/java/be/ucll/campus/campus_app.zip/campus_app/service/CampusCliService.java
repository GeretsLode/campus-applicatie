package be.ucll.campus.campus_app.service;

import be.ucll.campus.campus_app.model.Campus;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import java.util.List;
import java.util.Scanner;

@Service
public class CampusCliService {
    private final WebClient webClient;

    public CampusCliService(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.baseUrl("http://localhost:8080").build();
    }

    public void campusMenu(Scanner scanner) {
        while (true) {
            System.out.println("\n--- Campusbeheer ---");
            System.out.println("1. Alle campussen bekijken");
            System.out.println("2. Specifieke campus opvragen");
            System.out.println("3. Campus toevoegen");
            System.out.println("4. Terug naar hoofdmenu");
            System.out.print("Kies een optie: ");

            int keuze = scanner.nextInt();
            scanner.nextLine();

            switch (keuze) {
                case 1 -> getAllCampuses();
                case 2 -> {
                    System.out.print("Geef de naam van de campus: ");
                    String campusNaam = scanner.nextLine().trim();
                    getCampusById(campusNaam);
                }
                case 3 -> {
                    System.out.print("Geef de naam van de nieuwe campus: ");
                    String naam = scanner.nextLine();
                    System.out.print("Geef het adres van de campus: ");
                    String adres = scanner.nextLine();
                    System.out.print("Geef het aantal parkeerplaatsen: ");
                    int parkeerplaatsen = scanner.nextInt();
                    scanner.nextLine();
                    addCampus(new Campus(naam, adres, parkeerplaatsen));
                }
                case 4 -> {
                    return;
                }
                default -> System.out.println("Ongeldige keuze.");
            }
        }
    }

    private void getAllCampuses() {
        List<Campus> campuses = webClient.get()
                .uri("/campus")
                .retrieve()
                .bodyToFlux(Campus.class)
                .collectList()
                .block();

        if (campuses == null || campuses.isEmpty()) {
            System.out.println("Er zijn geen campussen gevonden.");
        } else {
            campuses.forEach(campus -> System.out.println(
                    "Naam: " + campus.getNaam() + ", Adres: " + campus.getAdres() + ", Parkeerplaatsen: " + campus.getParkeerplaatsen()
            ));
        }
    }

    private void getCampusById(String campusNaam) {
        Campus campus = webClient.get()
                .uri("/campus/" + campusNaam)
                .retrieve()
                .bodyToMono(Campus.class)
                .block();

        if (campus != null) {
            System.out.println("Naam: " + campus.getNaam());
            System.out.println("Adres: " + campus.getAdres());
            System.out.println("Parkeerplaatsen: " + campus.getParkeerplaatsen());
        } else {
            System.out.println("Campus niet gevonden.");
        }
    }

    private void addCampus(Campus campus) {
        Campus response = webClient.post()
                .uri("/campus")
                .bodyValue(campus)
                .retrieve()
                .bodyToMono(Campus.class)
                .block();

        if (response != null) {
            System.out.println("Campus succesvol toegevoegd: " + response.getNaam());
        } else {
            System.out.println("Fout bij het toevoegen van de campus.");
        }
    }
}
