package be.ucll.campus.campus_app.service;

import be.ucll.campus.campus_app.model.Campus;
import be.ucll.campus.campus_app.model.Lokaal;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import java.util.List;
import java.util.Scanner;

@Service
public class LokaalCliService {
    private final WebClient webClient;

    public LokaalCliService(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.baseUrl("http://localhost:8080").build();
    }

    public void lokaalMenu(Scanner scanner) {
        while (true) {
            System.out.println("\n--- Lokaalbeheer ---");
            System.out.println("1. Alle lokalen binnen een campus bekijken");
            System.out.println("2. Specifiek lokaal opvragen");
            System.out.println("3. Lokaal toevoegen aan campus");
            System.out.println("4. Lokaal verwijderen");
            System.out.println("5. Terug naar hoofdmenu");
            System.out.print("Kies een optie: ");

            int keuze = scanner.nextInt();
            scanner.nextLine();

            switch (keuze) {
                case 1 -> getAllLokalen(scanner);
                case 2 -> getLokaalById(scanner);
                case 3 -> addLokaal(scanner);
                case 4 -> deleteLokaal(scanner);
                case 5 -> {
                    return;
                }
                default -> System.out.println("Ongeldige keuze.");
            }
        }
    }

    private void addLokaal(Scanner scanner) {
        System.out.print("Geef de naam van de campus: ");
        String campusNaam = scanner.nextLine().trim();
        System.out.print("Geef de naam van het lokaal: ");
        String naam = scanner.nextLine().trim();
        System.out.print("Geef het type lokaal: ");
        String type = scanner.nextLine().trim();
        System.out.print("Geef de capaciteit: ");
        int capaciteit = scanner.nextInt();
        System.out.print("Geef de verdieping: ");
        int verdieping = scanner.nextInt();
        scanner.nextLine();

        Lokaal lokaal = new Lokaal(naam, type, capaciteit, verdieping, campusNaam);

        webClient.post()
                .uri("/campus/" + campusNaam + "/rooms")
                .bodyValue(lokaal)
                .retrieve()
                .bodyToMono(Lokaal.class)
                .block();

        System.out.println("Lokaal succesvol toegevoegd.");
    }

    private void getAllLokalen(Scanner scanner) {
        System.out.print("Geef de naam van de campus: ");
        String campusNaam = scanner.nextLine().trim();

        List<Lokaal> lokalen = webClient.get()
                .uri("/campus/" + campusNaam + "/rooms")
                .retrieve()
                .bodyToFlux(Lokaal.class)
                .collectList()
                .block();

        if (lokalen == null || lokalen.isEmpty()) {
            System.out.println("Geen lokalen gevonden in campus " + campusNaam);
        } else {
            lokalen.forEach(lokaal -> System.out.println(
                    "ID: " + lokaal.getId() + ", Naam: " + lokaal.getNaam() +
                            ", Type: " + lokaal.getType() + ", Capaciteit: " + lokaal.getCapaciteit()
            ));
        }
    }

    private void getLokaalById(Scanner scanner) {
        System.out.print("Geef de naam van de campus: ");
        String campusNaam = scanner.nextLine().trim();
        System.out.print("Geef de ID van het lokaal: ");
        Long lokaalId = scanner.nextLong();
        scanner.nextLine();

        Lokaal lokaal = webClient.get()
                .uri("/campus/" + campusNaam + "/rooms/" + lokaalId)
                .retrieve()
                .bodyToMono(Lokaal.class)
                .block();

        if (lokaal != null) {
            System.out.println("Naam: " + lokaal.getNaam());
            System.out.println("Type: " + lokaal.getType());
            System.out.println("Capaciteit: " + lokaal.getCapaciteit());
        } else {
            System.out.println("Lokaal niet gevonden.");
        }
    }

    private void deleteLokaal(Scanner scanner) {
        System.out.print("Geef de naam van de campus: ");
        String campusNaam = scanner.nextLine().trim();
        System.out.print("Geef de ID van het lokaal: ");
        Long lokaalId = scanner.nextLong();
        scanner.nextLine();

        webClient.delete()
                .uri("/campus/" + campusNaam + "/rooms/" + lokaalId)
                .retrieve()
                .toBodilessEntity()
                .block();

        System.out.println("Lokaal succesvol verwijderd.");
    }
}

