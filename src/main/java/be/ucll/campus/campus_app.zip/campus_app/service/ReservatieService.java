package be.ucll.campus.campus_app.service;

import be.ucll.campus.campus_app.model.*;
import be.ucll.campus.campus_app.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import be.ucll.campus.campus_app.dto.ReservatieDTO;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import java.util.Optional;
import java.util.Set;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import be.ucll.campus.campus_app.exception.*;

@Service
public class ReservatieService {

    private final ReservatieRepository reservatieRepository;
    private final UserRepository userRepository;
    private final LokaalRepository lokaalRepository;
    private final ReservatieLokaalRepository reservatieLokaalRepository;

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");

    @Autowired
    public ReservatieService(ReservatieRepository reservatieRepository, UserRepository userRepository,
                             LokaalRepository lokaalRepository, ReservatieLokaalRepository reservatieLokaalRepository) {
        this.reservatieRepository = reservatieRepository;
        this.userRepository = userRepository;
        this.lokaalRepository = lokaalRepository;
        this.reservatieLokaalRepository = reservatieLokaalRepository;
    }

    public List<Reservatie> getAllReservaties() {
        return reservatieRepository.findAll();
    }

    public Optional<Reservatie> getReservatieById(Long id) {
        return reservatieRepository.findById(id);
    }

    public List<Reservatie> getReservatiesByUserId(Long userId) {
        return reservatieRepository.findByGebruikerId(userId);
    }

    @Transactional
    public Reservatie addReservatie(Long userId, String startTijdInput, String eindTijdInput, Set<Long> lokaalIds) {
        User gebruiker = userRepository.findById(userId)
                .orElseThrow(() -> new InvalidReservationException("Gebruiker niet gevonden"));

        LocalDateTime startTijd;
        LocalDateTime eindTijd;

        try {
            startTijd = LocalDateTime.parse(startTijdInput.trim(), FORMATTER);
            eindTijd = LocalDateTime.parse(eindTijdInput.trim(), FORMATTER);
        } catch (DateTimeParseException e) {
            throw new InvalidReservationException("Ongeldig datumformaat. Gebruik: yyyy-MM-dd'T'HH:mm");
        }

        // 1. Controle: Starttijd moet vóór de eindtijd liggen
        if (startTijd.isAfter(eindTijd)) {
            throw new InvalidReservationException("Starttijd moet vóór de eindtijd liggen.");
        }

        // 2. Controle: Reservatie mag niet in het verleden liggen
        if (eindTijd.isBefore(LocalDateTime.now())) {
            throw new InvalidReservationException("Reservatie kan niet in het verleden liggen.");
        }

        // 3. Controle: Overlappende reservaties vermijden
        for (Long lokaalId : lokaalIds) {
            if (reservatieRepository.existsByLokaalIdAndOverlappingTijd(lokaalId, startTijd, eindTijd)) {
                throw new InvalidReservationException("Lokaal is al gereserveerd in deze periode.");
            }
        }

        Reservatie reservatie = new Reservatie();
        reservatie.setGebruiker(gebruiker);
        reservatie.setStartTijd(startTijd);
        reservatie.setEindTijd(eindTijd);
        Reservatie nieuweReservatie = reservatieRepository.save(reservatie);

        for (Long lokaalId : lokaalIds) {
            Lokaal lokaal = lokaalRepository.findById(lokaalId)
                    .orElseThrow(() -> new InvalidReservationException("Lokaal niet gevonden"));

            ReservatieLokaal reservatieLokaal = new ReservatieLokaal();
            ReservatieLokaalId reservatieLokaalId = new ReservatieLokaalId(nieuweReservatie.getId(), lokaal.getId());

            reservatieLokaal.setId(reservatieLokaalId);
            reservatieLokaal.setReservatie(nieuweReservatie);
            reservatieLokaal.setLokaal(lokaal);


            reservatieLokaalRepository.saveAndFlush(reservatieLokaal);
}

        return nieuweReservatie;
    }


    @Transactional
    public void deleteReservatie(Long id) {
        if (!reservatieRepository.existsById(id)) {
            throw new IllegalArgumentException("Reservatie niet gevonden");
        }
        Reservatie reservatie = reservatieRepository.findById(id)
                .orElseThrow(() -> new InvalidReservationException("Reservatie niet gevonden"));
        List<ReservatieLokaal> reservatieLokalen = reservatieLokaalRepository.findByReservatie(reservatie);

        for (ReservatieLokaal reservatieLokaal : reservatieLokalen) {
            reservatieLokaalRepository.deleteById(reservatieLokaal.getId());
        }

        reservatieRepository.deleteById(id);
    }
}
