package be.ucll.campus.campus_app.dto;

import be.ucll.campus.campus_app.model.Reservatie;
import be.ucll.campus.campus_app.dto.KlantDTO;
import java.time.LocalDateTime;

public class ReservatieDTO {
    private Long id;
    private LocalDateTime startTijd;
    private LocalDateTime eindTijd;
    private String commentaar;
    private KlantDTO gebruiker;

    // Constructor
    public ReservatieDTO(Long id, LocalDateTime startTijd, LocalDateTime eindTijd, String commentaar, KlantDTO gebruiker) {
        this.id = id;
        this.startTijd = startTijd;
        this.eindTijd = eindTijd;
        this.commentaar = commentaar;
        this.gebruiker = gebruiker;
    }

    // Conversiemethode van entity naar DTO
    public static ReservatieDTO fromReservatie(Reservatie reservatie) {
        return new ReservatieDTO(
                reservatie.getId(),
                reservatie.getStartTijd(),
                reservatie.getEindTijd(),
                reservatie.getCommentaar(),
                KlantDTO.fromUser(reservatie.getGebruiker())
        );
    }

    // Getters en setters (eventueel gegenereerd via IDE)
    public Long getId() { return id; }
    public LocalDateTime getStartTijd() { return startTijd; }
    public LocalDateTime getEindTijd() { return eindTijd; }
    public String getCommentaar() { return commentaar; }
    public KlantDTO getGebruiker() { return gebruiker; }
}
