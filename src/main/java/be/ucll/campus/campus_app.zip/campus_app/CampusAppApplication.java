package be.ucll.campus.campus_app;

import be.ucll.campus.campus_app.service.CliService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import java.util.Arrays;

import be.ucll.campus.campus_app.service.CampusService;
import be.ucll.campus.campus_app.service.LokaalService;
import be.ucll.campus.campus_app.service.UserService;
import be.ucll.campus.campus_app.service.ReservatieService;

import be.ucll.campus.campus_app.model.Campus;
import be.ucll.campus.campus_app.model.Lokaal;
import be.ucll.campus.campus_app.model.User;
import be.ucll.campus.campus_app.model.Reservatie;
import org.springframework.context.annotation.ComponentScan;

import java.time.LocalDateTime;
import java.time.LocalDate;
import java.util.List;


@SpringBootApplication
@ComponentScan("be.ucll.campus.campus_app")
public class CampusAppApplication {
	public static void main(String[] args) {
		SpringApplication.run(CampusAppApplication.class, args);
		System.out.println("DEBUG: CampusAppApplication gestart.");
	}

	@Bean
	CommandLineRunner cliRunner(CliService cliService) {
		return args -> cliService.start();
	}
}


